const album = [];

module.exports = album;
