const mapDBToModelAlbum = ({ id, name, year }) => ({
  id,
  name,
  year,
});
module.exports = { mapDBToModelAlbum };
